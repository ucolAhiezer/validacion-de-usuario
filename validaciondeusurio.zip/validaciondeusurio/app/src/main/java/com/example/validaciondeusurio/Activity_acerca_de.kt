package com.example.validaciondeusurio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Activity_acerca_de : AppCompatActivity() {
    lateinit var boton:Button
    lateinit var tv1:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_acerca_de)

        boton=findViewById(R.id.button2)
        tv1=findViewById(R.id.textView)

        var msgs=intent.extras
        val dato=msgs?.getString("usuario")
        tv1.text=dato.toString()
        boton.setOnClickListener {
            finish()
        }

    }
}


























