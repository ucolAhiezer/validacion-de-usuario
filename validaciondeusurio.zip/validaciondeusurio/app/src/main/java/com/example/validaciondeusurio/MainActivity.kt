package com.example.validaciondeusurio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.content.Intent

class MainActivity : AppCompatActivity() {
    lateinit var et1: EditText
    lateinit var et2: EditText
    lateinit var boton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        et1 = findViewById(R.id.et1)
        et2 = findViewById(R.id.et2)
        boton = findViewById(R.id.button)

        boton.setOnClickListener {
            if (et1.text.toString().length == 0)
                Toast.makeText(this, "La clave no debe estar vacia", Toast.LENGTH_LONG).show()
            if (et2.text.toString().length == 0)
                Toast.makeText(this, "La clave no debe estar vacia", Toast.LENGTH_LONG).show()
            if (et1.text.equals("ivan") && et2.text.equals("12345")) {
                val intento = Intent(this, Activity_acerca_de::class.java)
                intento.putExtra("usuario", et1.text.toString())
                startActivity(intento)
            }
        }
    }
}